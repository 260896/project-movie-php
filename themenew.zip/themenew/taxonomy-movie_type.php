<?php 
// Sử dụng chung template với archive-movie.php để đồng nhất giao diện
include( locate_template( 'archive-movie.php' ) ); 
?>
