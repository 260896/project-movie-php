<?php 
include( locate_template( 'archive-movie.php' ) ); 
?>
